package de.upb.sse.jess.model.stubs;

public enum Visibility {
    PUBLIC, PROTECTED, PRIVATE
}
