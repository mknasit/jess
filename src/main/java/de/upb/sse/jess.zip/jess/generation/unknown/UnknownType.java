package de.upb.sse.jess.generation.unknown;

public class UnknownType {
    public final static String PACKAGE = "unknown";
    public final static String CLASS = "Unknown";
    public final static String TEMPLATE = String.format("package %s;\n\npublic class %s {}", PACKAGE, CLASS);
}
